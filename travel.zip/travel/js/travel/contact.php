<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <style>
        /* Resetting Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        /* Header Styles */
        .contact-head {
            padding: 6% 0;
            text-align: center;
        }

        .contact-head h3 {
            color: #60B0E6;
            font-size: 2em;
            margin-bottom: 1em;
        }

        .contact-head img {
            margin: 1em;
            width: 25px;
            height: 25px;
        }

        .contact-head span {
            display: inline-block;
            width: 6%;
            height: 1px;
            background: rgba(128, 128, 128, 0.24);
            vertical-align: middle;
            margin: 0 1em;
        }

        /* Address Section Styles */
        .address {
            text-align: center;
            margin-bottom: 2em;
        }

        .address h4 {
            color: #09F;
            font-size: 1.5em;
            margin-bottom: 0.5em;
        }

        .address p {
            color: #000;
            font-size: 1.1em;
            margin-bottom: 1em;
        }

        .address h5 {
            color: #5E686F;
            font-size: 1em;
            margin-bottom: 0.5em;
        }

        .address h5 a {
            color: #5E686F;
            text-decoration: none;
        }

        .address h5 a:hover {
            color: #60B0E6;
        }

        .address h5 span {
            display: inline-block;
            width: 25px;
            height: 28px;
            margin-right: 0.5em;
            vertical-align: middle;
        }

        .address h5 span.img1 {
            background: url("../images/contact-img.png") no-repeat 0 0;
        }

        .address h5 span.img2 {
            background: url("../images/contact-img.png") no-repeat 0 -33px;
        }

        .address h5 span.img3 {
            background: url("../images/contact-img.png") no-repeat 0 -68px;
        }

        .address img {
            width: 100%;
            height: auto;
            max-width: 200px;
            display: block;
            margin: 1em auto;
        }

        /* Form Section Styles */
        .contact form {
            width: 70%;
            margin: 0 auto;
            background-color: #fff;
            padding: 2em;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .contact form input[type="text"],
        .contact form textarea {
            width: calc(100% - 2em);
            margin-bottom: 1em;
            padding: 0.5em;
            border: 1px solid #ccc;
            border-radius: 3px;
            outline: none;
        }

        .contact form textarea {
            min-height: 150px;
            resize: vertical;
        }

        .contact form input[type="submit"] {
            background-color: #60B0E6;
            color: #fff;
            border: none;
            padding: 0.5em 2em;
            font-size: 1em;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
            outline: none;
        }

        .contact form input[type="submit"]:hover {
            background-color: #3f8ecb;
        }
    </style>
</head>
<body>
    <div id="section-5" class="contact section">
        <div class="contact-head">
            <h3>Contact Us</h3>
            <img src="images/mail.png" alt="Mail Icon">
            <span></span>
            <h4 style="color: #000;">Plan Your Trip. Our travel experts can help you book now!</h4>
            <div class="contact-grids">
                <div class="container">
                    <div class="col-md-4 address">
                        <h4>ABCD Enterprises</h4>
                        <p>NEED HELP BOOKING PACKAGE<br>For fantastic suggestions you may also call our travel expert</p>
                        <h5><span class="img1"></span>(+91) 9876543210&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;9874561230</h5>
                        <h5><span class="img2"></span><a href="#">www.code-projects.org&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;www.code-projects.org</a></h5>
                        <h5><span class="img3"></span>YOUR LOCATION</h5>
                        <img src="images/contac.jpg" alt="Contact Image">
                    </div>
                    <div class="col-md-8 contact">
                        <?php
                        if(isset($_POST["sbmt"])) {
                            // Handle form submission here
                            // Example: Inserting data into database
                            $servername = "localhost";
                            $username = "username";
                            $password = "password";
                            $dbname = "myDB";

                            // Create connection
                            $conn = new mysqli($servername, $username, $password, $dbname);
                            // Check connection
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            // Prepare and bind
                            $stmt = $conn->prepare("INSERT INTO contactus (Name, Phno, Email, Message) VALUES (?, ?, ?, ?)");
                            $stmt->bind_param("ssss", $name, $phno, $email, $message);

                            // set parameters and execute
                            $name = $_POST["t1"];
                            $phno = $_POST["t2"];
                            $email = $_POST["t3"];
                            $message = $_POST["t4"];
                            $stmt->execute();

                            echo "<script>alert('Record Save');</script>";

                            $stmt->close();
                            $conn->close();
                        }
                        ?>
                        <form method="post">
                            <input type="text" name="t1" placeholder="Name" required pattern="[a-zA-z1 _]{1,50}">
                            <input type="text" name="t2" placeholder="Contact No" required pattern="[0-9]{10,12}">
                            <input type="text" name="t3" placeholder="Email" required>
                            <textarea name="t4" placeholder="Message" required></textarea>
                            <input type="submit" value="Send message" name="sbmt">
                        </form>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
