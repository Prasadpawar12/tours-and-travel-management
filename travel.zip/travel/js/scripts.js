document.getElementById('login-form').addEventListener('submit', function(event) {
  event.preventDefault();
  var username = document.getElementById('username').value;
  var password = document.getElementById('password').value;
  
  // Perform authentication here (dummy example)
  if (username === 'admin' && password === 'password') {
    document.querySelector('.login-container').style.display = 'none';
    document.querySelector('.dashboard-container').style.display = 'block';
  } else {
    alert('Invalid username or password. Please try again.');
  }
});