<?php
    include 'dbcon.php';
    if(isset($_POST['submit'])){
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $pass = mysqli_real_escape_string($conn, md5($_POST['password']));
        $cpass = mysqli_real_escape_string($conn, md5($_POST['cpassword']));

        // Check if password and confirm password match
        if ($pass !== $cpass) {
            echo '<script>alert("Password and Confirm Password do not match!");</script>';
        } else {
            $select = mysqli_query($conn,"SELECT * FROM `user_form` WHERE email = '$email' and password =  '$pass'") or die('query failed');

            if(mysqli_num_rows($select) > 0){
                echo '<script>alert("User already exists!");</script>';
            } else {
                mysqli_query($conn, "INSERT INTO `user_form`(name,email,password) VALUES('$name','$email','$pass')") or die('query failed');
                echo '<script>alert("Registration Successful! You can now login."); window.location.href = "login.php";</script>';
                exit(); // Terminate script execution after redirection
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>register</title>
    <link rel="stylesheet" href="style.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=poppins:wght@100;200;300;400;500;600&display=swap');
        :root {
            --blue: #3498db;
            --red: #e74c3c;
            --orange: #f39c12;
            --black: #333;
            --white: #fff;
            --light-bg: rgba(238, 238, 238, 0.8); /* Transparent background color */
            --box-shadow: 0 5px 10px rgba(0, 0, 0, .1);
            --border: 2px solid var(--black);
        }

        body {
            background-image: url('images/img-14.jpg'); /* Add your background image here */
            background-size: cover;
            background-repeat: no-repeat;
            background-color: var(--light-bg); /* Fallback color if background image is not available */
            padding: 20px; /* Add padding to create space around the form */
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            outline: none;
            border: none;
            text-decoration: none;
        }

        .message {
            position: fixed; /* Change to fixed for perfect positioning */
            top: 20px; /* Adjust to your preference */
            left: 50%;
            transform: translateX(-50%); /* Center horizontally */
            padding: 15px 20px; /* Adjust padding for better size */
            background-color: var(--white);
            text-align: center;
            z-index: 1000;
            box-shadow: var(--box-shadow);
            color: var(--black);
            font-size: 16px; /* Adjust font size */
            text-transform: capitalize;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .message:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .btn,
        .delete-btn,
        .option-btn {
            display: inline-block;
            padding: 10px 30px;
            cursor: pointer;
            font-size: 16px; /* Adjust font size */
            color: var(--white);
            border-radius: 5px;
            text-transform: capitalize;
            transition: background-color 0.3s ease;
        }

        .btn:hover,
        .delete-btn:hover,
        .option-btn:hover {
            background-color: var(--black);
        }

        .btn {
            background-color: var(--blue);
            margin-top: 10px;
        }

        .delete-btn {
            background-color: var(--red);
        }

        .option-btn {
            background-color: var(--orange);
        }

        .form-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .form-container form {
            width: 100%; /* Adjust to your preference */
            max-width: 500px; /* Limit width for better readability */
            border-radius: 10px; /* Rounded corners */
            border: var(--border);
            padding: 40px;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.8); /* Transparent background color */
            box-shadow: var(--box-shadow);
            transition: box-shadow 0.3s ease;
        }

        .form-container form:hover {
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .form-container form h3 {
            font-size: 24px; /* Adjust font size */
            margin-bottom: 20px; /* Increased margin */
            text-transform: uppercase;
            color: var(--black);
        }

        .form-container form .box {
            width: calc(100% - 24px); /* Adjust width to account for padding */
            border-radius: 5px;
            border: var(--border);
            padding: 12px 14px;
            font-size: 16px; /* Adjust font size */
            margin: 10px auto; /* Center horizontally */
            transition: border-color 0.3s ease;
        }

        .form-container form .box:focus {
            border-color: var(--blue);
        }

        .form-container form .submit-btn {
            display: block;
            width: 100%;
            padding: 12px 0;
            margin-top: 20px;
            cursor: pointer;
            background-color: var(--orange);
            color: var(--white);
            border-radius: 5px;
            font-size: 16px;
            text-transform: uppercase;
            transition: background-color 0.3s ease;
        }

        .form-container form .submit-btn:hover {
            background-color: var(--black);
        }
    </style>
</head>
<body>
    <?php
        if (isset($message)){
            foreach($message as $message){
                echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
            }
        }
    ?>

    <div class="form-container">
        <form action="" method="POST">
            <h3>Register Now</h3>
            <input type="text" name="name"  required placeholder="Enter Username" class="box">  
            <input type="email" name="email"   required placeholder="Enter Email" class="box">
            <input type="password" name="password"    required placeholder="Enter Password" class="box">
            <input type="password" name="cpassword"   required placeholder="Confirm Password" class="box">
            <input type="submit" name="submit"  class="btn" value="Register Now">
            <p>Already have an account? <a href="login.php">Login Now</a></p>
        </form>
    </div>

    <script>
        function showSuccessAlert() {
            // Check if message contains success message
            <?php if ($message === 'Registration Successful! You can now login.'): ?>
                alert("Registration Successful! You can now login.");
            <?php endif; ?>
            return true; // Allow form submission
        }
    </script>
</body>
</html>
